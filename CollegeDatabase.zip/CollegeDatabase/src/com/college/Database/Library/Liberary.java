package com.college.Database.Library;

/**
 * This file is an Library main class which has stored getter & setter for
 * Library operations;;;;
 */

public class Liberary {

	private int id;
	private String name;
	private String streamName;
	private int libId;
	private String collegeName;
	private int status;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStreamName() {
		return streamName;
	}

	public void setStreamName(String streamName) {
		this.streamName = streamName;
	}

	public int getLibId() {
		return libId;
	}

	public void setLibId(int libId) {
		this.libId = libId;
	}

	public String getCollegeName() {
		return collegeName;
	}

	public void setCollegeName(String collegeName) {
		this.collegeName = collegeName;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "LiberaryData [id=" + id + ", name=" + name + ", streamName=" + streamName + ", libId=" + libId
				+ ", collegeName=" + collegeName + ", getId()=" + getId() + ", getName()=" + getName()
				+ ", getStreamName()=" + getStreamName() + ", getLibId()=" + getLibId() + ", getCollegeName()="
				+ getCollegeName() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}

}
