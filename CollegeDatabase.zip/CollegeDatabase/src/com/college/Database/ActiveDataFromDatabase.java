package com.college.Database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

import com.college.Database.Dbconnection.DbConnection;

/**
 * This file is used for getting Active Data which is stored value 1   ;;;;;
 */
public class ActiveDataFromDatabase {
	Scanner sc = new Scanner(System.in);
	MenuMethod menuMethod = new MenuMethod();

	public void activeCollegeData(String typeOfActiveData) {
		if (typeOfActiveData.equalsIgnoreCase("Student")) {
			/**
			 * Students Active Display Data ########
			 */
			try {
				Connection con = DbConnection.getConnect();
				PreparedStatement pst = con.prepareStatement("Select * from students where status = 1");
				ResultSet rs = pst.executeQuery();
				while (rs.next()) {
					System.out
							.println(rs.getInt(1) + "|" + rs.getString(2) + "|" + rs.getString(3) + "|" + rs.getString(4) + "|" + rs.getInt(5) + "|" + rs.getInt(6));
				}
				menuMethod.menu();
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}
		} else if (typeOfActiveData.equalsIgnoreCase("Teacher")) {
			/**
			 * Teachers Active Display Data ########
			 */
			try {
				Connection con = DbConnection.getConnect();
				PreparedStatement pst = con.prepareStatement("Select * from teachers where status = 1");
				ResultSet rs = pst.executeQuery();
				while (rs.next()) {
					System.out.println(rs.getInt(1) + "|" + rs.getString(2) + "|" + rs.getString(3) + "|" + rs.getString(4)
							+ "|" + rs.getInt(5) + "|" + rs.getInt(6));
				}
				menuMethod.menu();
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}

		} else if (typeOfActiveData.equalsIgnoreCase("Cource")) {
			/**
			 * // Courses Active Display Data ########
			 */
			try {
				Connection con = DbConnection.getConnect();
				PreparedStatement pst = con.prepareStatement("Select * from cources where status = 1");
				ResultSet rs = pst.executeQuery();
				while (rs.next()) {
					System.out.println(rs.getInt(1) + "|" + rs.getString(2) + "|" + rs.getString(3) + "|" + rs.getInt(4)
							+ "|" + rs.getInt(5));
				}
				menuMethod.menu();
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}

		} else if (typeOfActiveData.equalsIgnoreCase("Department")) {
			/**
			 * Department Active Display Data ########
			 */
			try {
				Connection con = DbConnection.getConnect();
				PreparedStatement pst = con.prepareStatement("Select * from departments where status = 1");
				ResultSet rs = pst.executeQuery();
				while (rs.next()) {
					System.out.println(rs.getInt(1) + "|" + rs.getString(2) + "|" + rs.getString(3) + "|" + rs.getInt(4)
							+ "|" + rs.getDate(5) + "|" + rs.getInt(6));
				}
				menuMethod.menu();
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}

		} else if (typeOfActiveData.equalsIgnoreCase("Admin")) {
			/**
			 * // Admin Active Display Data ########
			 */
			try {
				Connection con = DbConnection.getConnect();
				PreparedStatement pst = con.prepareStatement("Select * from admin where status = 1");
				ResultSet rs = pst.executeQuery();
				while (rs.next()) {
					System.out.println(rs.getInt(1) + "|" + rs.getString(2) + "|" + rs.getString(3) + "|" + rs.getInt(4)
							+ "|" + rs.getDate(5) + "|" + rs.getString(6) + "|" + rs.getString(7));
				}
				menuMethod.menu();
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}

		} else if (typeOfActiveData.equalsIgnoreCase("Liberary")) {
			/**
			 * // Library Active Display Data ########
			 */
			try {
				Connection con = DbConnection.getConnect();
				PreparedStatement pst = con.prepareStatement("Select * from liberary where status = 1");
				ResultSet rs = pst.executeQuery();
				while (rs.next()) {
					System.out.println(rs.getInt(1) + "|" + rs.getString(2) + "|" + rs.getString(3) + "|" + rs.getInt(4)
							+ "|" + rs.getString(5) + "|" + rs.getInt(6));
				}
				menuMethod.menu();
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}

		} else if (typeOfActiveData.equalsIgnoreCase("Sport")) {
			/**
			 * // Sports Active Display Data ########
			 */
			try {
				Connection con = DbConnection.getConnect();
				PreparedStatement pst = con.prepareStatement("Select * from sports where status = 1");
				ResultSet rs = pst.executeQuery();
				while (rs.next()) {
					System.out.println(rs.getInt(1) + "|" + rs.getString(2) + "|" + rs.getString(3) + "|" + rs.getInt(4)
							+ "|" + rs.getString(5) + "|" + rs.getInt(6));
				}
				menuMethod.menu();
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}

		}
	}

}
