package com.college.Database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

import com.college.Database.Admins.Admin;
import com.college.Database.Cource.Cources;
import com.college.Database.Dbconnection.DbConnection;
import com.college.Database.Departments.Department;
import com.college.Database.Library.Liberary;
import com.college.Database.Sport.Sports;
import com.college.Database.Student.Students;
import com.college.Database.Teacher.Teachers;

/**
 * This file is used for Updating existing Data in DataBase;;;;;
 */

public class UpdateDataIntoDatabase {
	MenuMethod menuMethod = new MenuMethod();
	Scanner sc = new Scanner(System.in);

	public void updateData(String typeOfUpdate) {
		if (typeOfUpdate.equalsIgnoreCase("Student")) {
			/**
			 * // Students Updating Data ########
			 */
			Students std = new Students();
			System.out.println("Enter Name here:");
			String name = sc.next();
			std.setName(name);

			System.out.println("Enter Address here:");
			String address = sc.next();
			std.setAddress(address);	

			System.out.println("Enter Marks here:");
			int marks = sc.nextInt();
			std.setMarks(marks);

			System.out.println("Enter Status here:");
			int status = sc.nextInt();
			std.setStatus(status);

			System.out.println("Enter id here:");
			int id = sc.nextInt();
			std.setId(id);
			try {
				Connection con = DbConnection.getConnect();
				String str = "update students set name=?, address=?, marks=?, Status=? where id=?";
				PreparedStatement pst = con.prepareStatement(str);

				pst.setString(1, std.getName());
				pst.setString(2, std.getAddress());
				pst.setInt(3, std.getMarks());
				pst.setInt(4, std.getStatus());
				pst.setInt(5, std.getId());

				int x = pst.executeUpdate();
				pst.close();
				con.close();
				if (x == 1) {
					System.out.println("Record Updated");
					menuMethod.menu();
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}
		} else if (typeOfUpdate.equalsIgnoreCase("Teacher")) {
			/**
			 * // Teachers Updating Data ########
			 */
			Teachers teacher = new Teachers();
			System.out.println("Enter Name here:");
			String name = sc.next();
			teacher.setName(name);

			System.out.println("Enter Teacher Name here:");
			String teachername = sc.next();
			teacher.setTeacherName(teachername);

			System.out.println("Enter Student Id here:");
			int StdId = sc.nextInt();
			teacher.setStdId(StdId);

			System.out.println("Enter Status here:");
			int status = sc.nextInt();
			teacher.setStatus(status);

			System.out.println("Enter id here:");
			int id = sc.nextInt();
			teacher.setId(id);
			try {
				Connection con = DbConnection.getConnect();
				String str = "update teachers set name=?, teacherName=?, stdId=?, status=? where id=?";
				PreparedStatement pst = con.prepareStatement(str);

				pst.setString(1, teacher.getName());
				pst.setString(2, teacher.getTeacherName());
				pst.setInt(3, teacher.getStdId());
				pst.setInt(4, teacher.getStatus());
				pst.setInt(5, teacher.getId());

				int x = pst.executeUpdate();
				pst.close();
				con.close();
				if (x == 1) {
					System.out.println("Record Updated");
					menuMethod.menu();
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}
		} else if (typeOfUpdate.equalsIgnoreCase("Cource")) {
			/**
			 * // Courses Updating Data ########
			 */
			Cources cources = new Cources();
			System.out.println("Enter Course Name here:");
			String courseName = sc.next();
			cources.setCourseName(courseName);

			System.out.println("Enter Course Code here:");
			String courseCode = sc.next();
			cources.setCourseCode(courseCode);

			System.out.println("Enter Department Id here:");
			int departmentId = sc.nextInt();
			cources.setDepartmentId(departmentId);

			System.out.println("Enter Status here:");
			int Status = sc.nextInt();
			cources.setStatus(Status);

			System.out.println("Enter id here:");
			int id = sc.nextInt();
			cources.setId(id);
			try {
				Connection con = DbConnection.getConnect();
				String str = "update cources set courseName=?, courseCode=?, departmentId=?, Status=? where id=?";
				PreparedStatement pst = con.prepareStatement(str);

				pst.setString(1, cources.getCourseName());
				pst.setString(2, cources.getCourseCode());
				pst.setInt(3, cources.getDepartmentId());
				pst.setInt(4, cources.getStatus());
				pst.setInt(5, cources.getId());

				int x = pst.executeUpdate();
				pst.close();
				con.close();
				if (x == 1) {
					System.out.println("Record Updated");
					menuMethod.menu();
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}

		} else if (typeOfUpdate.equalsIgnoreCase("Department")) {
			/**
			 * // Department Updating Data ########
			 */
			Department department = new Department();
			System.out.println("Enter Name here:");
			String name = sc.next();
			department.setName(name);

			System.out.println("Enter Department Name here:");
			String departmentName = sc.next();
			department.setDepartmentName(departmentName);

			System.out.println("Enter Department Id here:");
			int departmentId = sc.nextInt();
			department.setDepartmentId(departmentId);

			System.out.println("Enter Addmission date here");
			String addmissiondate = sc.next();
			department.setAddmissionDate(addmissiondate);

			System.out.println("Enter Status here:");
			int status = sc.nextInt();
			department.setStatus(status);

			System.out.println("Enter id here:");
			int id = sc.nextInt();
			department.setId(id);
			try {
				Connection con = DbConnection.getConnect();
				String str = "update departments set name=?, departmentName=?, departmentId=?, addmissionDate=?, status=?  where id=?";
				PreparedStatement pst = con.prepareStatement(str);

				pst.setString(1, department.getName());
				pst.setString(2, department.getDepartmentName());
				pst.setInt(3, department.getDepartmentId());
				pst.setString(4, department.getAddmissionDate());
				pst.setInt(5, department.getStatus());
				pst.setInt(6, department.getId());

				int x = pst.executeUpdate();
				pst.close();
				con.close();
				if (x == 1) {
					System.out.println("Record Updated");
					menuMethod.menu();
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}

		} else if (typeOfUpdate.equalsIgnoreCase("Admin")) {
			/**
			 * // Admin Updating Data ########
			 */
			Admin admin = new Admin();
			System.out.println("Enter Name here:");
			String name = sc.next();
			admin.setName(name);

			System.out.println("Enter Stream Name here:");
			String streamName = sc.next();
			admin.setStreamName(streamName);

			System.out.println("Enter Addmission Id here:");
			int addmissionId = sc.nextInt();
			admin.setAddmissionId(addmissionId);

			System.out.println("Enter Addmission date here");
			String addmissiondate = sc.next();
			admin.setAddmissionDate(addmissiondate);

			System.out.println("Enter Status here");
			int status = sc.nextInt();
			admin.setStatus(status);

			System.out.println("Enter id here:");
			int id = sc.nextInt();
			admin.setId(id);
			try {
				Connection con = DbConnection.getConnect();
				String str = "update admin set name=?, streamName=?, addmissionId=?, addmissionDate=?, status=? where id=?";
				PreparedStatement pst = con.prepareStatement(str);

				pst.setString(1, admin.getName());
				pst.setString(2, admin.getStreamName());
				pst.setInt(3, admin.getAddmissionId());
				pst.setString(4, admin.getAddmissionDate());
				pst.setInt(5, admin.getStatus());
				pst.setInt(6, admin.getId());

				int x = pst.executeUpdate();
				pst.close();
				con.close();
				if (x == 1) {
					System.out.println("Record Updated");
					menuMethod.menu();
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}

		} else if (typeOfUpdate.equalsIgnoreCase("Liberary")) {
			/**
			 * // Library Updating Data ########
			 */
			Liberary liberary = new Liberary();
			System.out.println("Enter Name here:");
			String name = sc.next();
			liberary.setName(name);

			System.out.println("Enter Stream Name here:");
			String streamName = sc.next();
			liberary.setStreamName(streamName);

			System.out.println("Enter Library Id here:");
			int libId = sc.nextInt();
			liberary.setLibId(libId);

			System.out.println("Enter College name here");
			String collegeName = sc.next();
			liberary.setCollegeName(collegeName);

			System.out.println("Enter Status here:");
			int Status = sc.nextInt();
			liberary.setStatus(Status);

			System.out.println("Enter id here:");
			int id = sc.nextInt();
			liberary.setId(id);
			try {
				Connection con = DbConnection.getConnect();
				String str = "update liberary set name=?, streamName=?, libId=?, collegeName=?, status=? where id=?";
				PreparedStatement pst = con.prepareStatement(str);

				pst.setString(1, liberary.getName());
				pst.setString(2, liberary.getStreamName());
				pst.setInt(3, liberary.getLibId());
				pst.setString(4, liberary.getCollegeName());
				pst.setInt(5, liberary.getStatus());
				pst.setInt(6, liberary.getId());

				int x = pst.executeUpdate();
				pst.close();
				con.close();
				if (x == 1) {
					System.out.println("Record Updated");
					menuMethod.menu();
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}

		} else if (typeOfUpdate.equalsIgnoreCase("Sport")) {
			/**
			 * // Sports Updating Data ########
			 */
			Sports sport = new Sports();
			System.out.println("Enter Name here:");
			String name = sc.next();
			sport.setName(name);

			System.out.println("Enter Stream Name here:");
			String streamName = sc.next();
			sport.setStreamName(streamName);

			System.out.println("Enter Sports Id here:");
			int sportsId = sc.nextInt();
			sport.setSportsId(sportsId);

			System.out.println("Enter Sports Name here");
			String sportsName = sc.next();
			sport.setSportsName(sportsName);

			System.out.println("Enter Status here:");
			int status = sc.nextInt();
			sport.setStatus(status);

			System.out.println("Enter id here:");
			int id = sc.nextInt();
			sport.setId(id);
			try {
				Connection con = DbConnection.getConnect();
				String str = "update sports set name=?, streamName=?, sportsId=?, sportsName=?, status=? where id=?";
				PreparedStatement pst = con.prepareStatement(str);

				pst.setString(1, sport.getName());
				pst.setString(2, sport.getStreamName());
				pst.setInt(3, sport.getSportsId());
				pst.setString(4, sport.getSportsName());
				pst.setInt(5, sport.getStatus());
				pst.setInt(6, sport.getId());

				int x = pst.executeUpdate();
				pst.close();
				con.close();
				if (x == 1) {
					System.out.println("Record Updated");
					menuMethod.menu();
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}

		}
	}
}
