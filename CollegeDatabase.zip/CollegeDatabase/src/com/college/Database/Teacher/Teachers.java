	package com.college.Database.Teacher;

/**
 * This file is an Teachers main class which has stored getter & setter for
 * Teachers operations;;;;
 */

public class Teachers {

	private int id;
	private String name;
	private String email;
	private String teacherName;
	private int stdId;
	private int status;
	private String password;


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTeacherName() {
		return teacherName;
	}

	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}

	public int getStdId() {
		return stdId;
	}

	public void setStdId(int stdId) {
		this.stdId = stdId;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}
	
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}


	@Override
	public String toString() {
		return "Teachers [id=" + id + ", name=" + name + ", email=" + email + ", teacherName=" + teacherName
				+ ", stdId=" + stdId + ", status=" + status + ", password=" + password + ", getId()=" + getId()
				+ ", getName()=" + getName() + ", getEmail()=" + getEmail() + ", getTeacherName()=" + getTeacherName()
				+ ", getStdId()=" + getStdId() + ", getStatus()=" + getStatus() + ", getPassword()=" + getPassword()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
				+ "]";
	}

}
