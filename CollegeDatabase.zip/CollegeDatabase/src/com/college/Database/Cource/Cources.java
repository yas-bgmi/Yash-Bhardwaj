package com.college.Database.Cource;

/**
 * This file is an Course main class which has stored getter & setter for Course
 * operations;;;;
 */

public class Cources {

	private int id;
	private String courseName;
	private String courseCode;
	private int departmentId;
	private int status;

	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public String getCourseName() {
		return courseName;
	}



	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}



	public String getCourseCode() {
		return courseCode;
	}



	public void setCourseCode(String courseCode) {
		this.courseCode = courseCode;
	}



	public int getDepartmentId() {
		return departmentId;
	}



	public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}



	public int getStatus() {
		return status;
	}



	public void setStatus(int status) {
		this.status = status;
	}



	@Override
	public String toString() {
		return "Cources [id=" + id + ", courseName=" + courseName + ", courseCode=" + courseCode + ", departmentId="
				+ departmentId + ", status=" + status + ", getId()=" + getId() + ", getCourseName()=" + getCourseName()
				+ ", getCourseCode()=" + getCourseCode() + ", getDepartmentId()=" + getDepartmentId() + ", getStatus()="
				+ getStatus() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}

	

}
