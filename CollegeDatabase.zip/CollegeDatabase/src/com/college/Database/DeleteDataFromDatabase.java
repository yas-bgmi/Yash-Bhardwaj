package com.college.Database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

import com.college.Database.Admins.Admin;
import com.college.Database.Cource.Cources;
import com.college.Database.Dbconnection.DbConnection;
import com.college.Database.Departments.Department;
import com.college.Database.Library.Liberary;
import com.college.Database.Sport.Sports;
import com.college.Database.Student.Students;
import com.college.Database.Teacher.Teachers;

/**
 * This file is used for Deleting Data from DataBase ;;;;;
 */

public class DeleteDataFromDatabase {

	Scanner sc = new Scanner(System.in);
	MenuMethod menuMethod = new MenuMethod();

	public void deleteData(String typeOfDelete) {
		if (typeOfDelete.equalsIgnoreCase("Student")) {
			/**
			 * // Students Delete Data from Database ########
			 */
			try {
				int id;
				System.out.println("Enter the record number id to delete");
				id = sc.nextInt();
				Students std = new Students();
				std.setId(id);
				Connection con = DbConnection.getConnect();

				PreparedStatement pst = con.prepareStatement("delete from students where id=?");
				pst.setInt(1, std.getId());

				int x = pst.executeUpdate();
				pst.close();
				con.close();
				if (x == 1) {
					System.out.println("Record is now deleted");
					menuMethod.menu();
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}
		} else if (typeOfDelete.equalsIgnoreCase("Teacher")) {
			/**
			 * // Teachers Delete Data from Database ########
			 */
			try {
				int id;
				System.out.println("Enter the record number id to delete");
				id = sc.nextInt();
				Teachers teacher = new Teachers();
				teacher.setId(id);
				Connection con = DbConnection.getConnect();
				PreparedStatement pst = con.prepareStatement("delete from teachers where id=?");
				pst.setInt(1, teacher.getId());

				int x = pst.executeUpdate();
				pst.close();
				con.close();
				if (x == 1) {
					System.out.println("Record is now deleted");
					menuMethod.menu();
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}

		} else if (typeOfDelete.equalsIgnoreCase("Cource")) {
			/**
			 * // Courses Delete Data from Database ########
			 */
			try {
				int id;
				System.out.println("Enter the record number id to delete");
				id = sc.nextInt();
				Cources cources = new Cources();
				cources.setId(id);
				Connection con = DbConnection.getConnect();
				PreparedStatement pst = con.prepareStatement("delete from cources where id=?");
				pst.setInt(1, cources.getId());

				int x = pst.executeUpdate();
				pst.close();
				con.close();
				if (x == 1) {
					System.out.println("Record is now deleted");
					menuMethod.menu();
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}

		} else if (typeOfDelete.equalsIgnoreCase("Department")) {
			/**
			 * // Department Delete Data from Database ########
			 */
			try {
				int id;
				System.out.println("Enter the record number id to delete");
				id = sc.nextInt();
				Department department = new Department();
				department.setId(id);
				Connection con = DbConnection.getConnect();
				PreparedStatement pst = con.prepareStatement("delete from departments where id=?");
				pst.setInt(1, department.getId());

				int x = pst.executeUpdate();
				pst.close();
				con.close();
				if (x == 1) {
					System.out.println("Record is now deleted");
					menuMethod.menu();
				} else {
					System.out.println("Record not found");
					menuMethod.menu();
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}

		} else if (typeOfDelete.equalsIgnoreCase("Admin")) {
			/**
			 * // Admin Delete Data from Database ########
			 */
			try {
				int id;
				System.out.println("Enter the record number id to delete");
				id = sc.nextInt();
				Admin admin = new Admin();
				admin.setId(id);
				Connection con = DbConnection.getConnect();
				PreparedStatement pst = con.prepareStatement("delete from admin where id=?");
				pst.setInt(1, admin.getId());

				int x = pst.executeUpdate();
				pst.close();
				con.close();
				if (x == 1) {
					System.out.println("Record is now deleted");
					menuMethod.menu();
				} else {
					System.out.println("Record not found");
					menuMethod.menu();
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}

		} else if (typeOfDelete.equalsIgnoreCase("Liberary")) {
			/**
			 * // Library Delete Data from Database ########
			 */
			try {
				int id;
				System.out.println("Enter the record number id to delete");
				id = sc.nextInt();
				Liberary liberary = new Liberary();
				liberary.setId(id);
				Connection con = DbConnection.getConnect();
				PreparedStatement pst = con.prepareStatement("delete from liberary where id=?");
				pst.setInt(1, liberary.getId());

				int x = pst.executeUpdate();
				pst.close();
				con.close();
				if (x == 1) {
					System.out.println("Record is now deleted");
					menuMethod.menu();
				} else {
					System.out.println("Record not found");
					menuMethod.menu();
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}

		} else if (typeOfDelete.equalsIgnoreCase("Sport")) {
			/**
			 * // Sports Delete Data from Database ########
			 */
			try {
				int id;
				System.out.println("Enter the record number id to delete");
				id = sc.nextInt();
				Sports sport = new Sports();
				sport.setId(id);
				Connection con = DbConnection.getConnect();
				PreparedStatement pst = con.prepareStatement("delete from sports where id=?");
				pst.setInt(1, sport.getId());

				int x = pst.executeUpdate();
				pst.close();
				con.close();
				if (x == 1) {
					System.out.println("Record is now deleted");
					menuMethod.menu();
				} else {
					System.out.println("Record not found");
					menuMethod.menu();
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}

		}
	}
}
