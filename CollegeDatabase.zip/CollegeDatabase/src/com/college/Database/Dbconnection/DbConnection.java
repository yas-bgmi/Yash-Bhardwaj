package com.college.Database.Dbconnection;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 * This File is used to for connecting DataBase
 */
public class DbConnection {
    public static Connection getConnect() {
        try {
            DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/college", "root", "asdf@1234");
            return con;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
