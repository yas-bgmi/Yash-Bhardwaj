package com.college.Database.Admins;

/**
 * This file is an Admin main class which has stored getter & setter for Admin
 * operations;;;;
 */

public class Admin {

	private int id;
	private String name;
	private String streamName;
	private int addmissionId;
	private String addmissionDate;
	private int status;
	private String email;
	private String password;

	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getStreamName() {
		return streamName;
	}



	public void setStreamName(String streamName) {
		this.streamName = streamName;
	}



	public int getAddmissionId() {
		return addmissionId;
	}



	public void setAddmissionId(int addmissionId) {
		this.addmissionId = addmissionId;
	}



	public String getAddmissionDate() {
		return addmissionDate;
	}



	public void setAddmissionDate(String addmissionDate) {
		this.addmissionDate = addmissionDate;
	}



	public int getStatus() {
		return status;
	}



	public void setStatus(int status) {
		this.status = status;
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	public String getPassword() {
		return password;
	}



	public void setPassword(String password) {
		this.password = password;
	}


	@Override
	public String toString() {
		return "Admin [id=" + id + ", name=" + name + ", streamName=" + streamName + ", addmissionId=" + addmissionId
				+ ", addmissionDate=" + addmissionDate + ", status=" + status + ", email=" + email + ", password="
				+ password + ", getId()=" + getId() + ", getName()=" + getName() + ", getStreamName()="
				+ getStreamName() + ", getAddmissionId()=" + getAddmissionId() + ", getAddmissionDate()="
				+ getAddmissionDate() + ", getStatus()=" + getStatus() + ", getEmail()=" + getEmail()
				+ ", getPassword()=" + getPassword() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ ", toString()=" + super.toString() + "]";
	}

}
