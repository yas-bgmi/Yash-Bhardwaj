package com.college.Database;

import java.util.Scanner;

/**
 * This is Main Class
 */
public class MainClass {

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Greetings of the day\n" + "Please enter your name: ");
		String entername = sc.next();
		System.out.println("Hello " + "" + entername);

		// Menu Methods
		MenuMethod menuMethod = new MenuMethod();
		menuMethod.menu();
		sc.close();
	}
}