package com.college.Database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

import com.college.Database.Admins.Admin;
import com.college.Database.Cource.Cources;
import com.college.Database.Dbconnection.DbConnection;
import com.college.Database.Departments.Department;
import com.college.Database.Library.Liberary;
import com.college.Database.Sport.Sports;
import com.college.Database.Student.Students;
import com.college.Database.Teacher.Teachers;

/**
 * This file is used for Inserting Data in DataBase;;;;;
 */

public class InsertDataIntoDatabase {
	MenuMethod menuMethod = new MenuMethod();
	Scanner sc = new Scanner(System.in);

	public void insertData(String typeOfInsert) {
		if (typeOfInsert.equalsIgnoreCase("Student")) {
			/**
			 * // Students Inserting Data ########
			 */
			Students std = new Students();
			


			System.out.println("Enter your Name here:");
			String name = sc.next();
			std.setName(name);

			System.out.println("Enter your Email here:");
			String email = sc.next();
			std.setEmail(email);
			
			System.out.println("Enter your Address here:");
			String address = sc.next();
			std.setAddress(address);

			System.out.println("Enter your Marks here:");
			int marks = sc.nextInt();
			std.setMarks(marks);

			System.out.println("Choose your status 1 or 0");
			int status = sc.nextInt();
			std.setStatus(status);
			
			System.out.println("Enter your password here");
			String password = sc.next();
			std.setPassword(password);


			try {
				Connection con = DbConnection.getConnect();
				PreparedStatement pst = con
						.prepareStatement("Insert into students(name,email,address,marks,status,password)values(?,?,?,?,?,?)");
				pst.setString(1, std.getName());
				pst.setString(2, std.getEmail());
				pst.setString(3, std.getAddress());
				pst.setInt(4, std.getMarks());
				pst.setInt(5, std.getStatus());
				pst.setString(6, std.getPassword());
				//System.out.println("query submitted"+ pst);

				int x = pst.executeUpdate();
				pst.close();
				con.close();
				if (x == 1) {
					System.out.println("Record Inserted");
					menuMethod.menu();
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}
		} else if (typeOfInsert.equalsIgnoreCase("Teacher")) {
			/**
			 * // Teachers Inserting Data ########
			 */
			Teachers teacher = new Teachers();
			System.out.println("Enter your Name here:");
			String name = sc.next();
			teacher.setName(name);
			
			System.out.println("Enter your Email here:");
			String email = sc.next();
			teacher.setEmail(email);

			System.out.println("Enter your Teacher Name here:");
			String teacherName = sc.next();
			teacher.setTeacherName(teacherName);

			System.out.println("Enter your Std Id here:");
			int stdId = sc.nextInt();
			teacher.setStdId(stdId);

			System.out.println("Enter your Status Id here:");
			int status = sc.nextInt();
			teacher.setStatus(status);
			
			System.out.println("Enter your Password here:");
			String password = sc.next();
			teacher.setPassword(password);

			try {
				Connection con = DbConnection.getConnect();
				PreparedStatement pst = con
						.prepareStatement("Insert into teachers(name,email,teacherName,stdid,status,password)values(?,?,?,?,?,?)");
				pst.setString(1, teacher.getName());
				pst.setString(2, teacher.getEmail());
				pst.setString(3, teacher.getTeacherName());
				pst.setInt(4, teacher.getStdId());
				pst.setInt(5, teacher.getStatus());
				pst.setString(6, teacher.getPassword());
                //System.out.println("query submitted"+ pst);
				int x = pst.executeUpdate();
				pst.close();
				con.close();
				if (x == 1) {
					System.out.println("Record Inserted");
					menuMethod.menu();
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}
		} else if (typeOfInsert.equalsIgnoreCase("Cource")) {
			/**
			 * // Courses Inserting Data ########
			 */
			Cources cources = new Cources();
			System.out.println("Enter your Course Name here:");
			String courseName = sc.next();
			cources.setCourseName(courseName);

			System.out.println("Enter your Course code:");
			String courseCode = sc.next();
			cources.setCourseCode(courseCode);

			System.out.println("Enter your Department id here:");
			int departmentId = sc.nextInt();
			cources.setDepartmentId(departmentId);

			System.out.println("Enter your Status here:");
			int status = sc.nextInt();
			cources.setStatus(status);

			try {
				Connection con = DbConnection.getConnect();
				PreparedStatement pst = con.prepareStatement(
						"Insert into cources(courseName,courseCode,departmentId,status)values(?,?,?,?)");
				//pst.setInt(1, cources.getId());
				pst.setString(1, cources.getCourseName());
				pst.setString(2, cources.getCourseCode());
				pst.setInt(3, cources.getDepartmentId());
				pst.setInt(4, cources.getStatus());

				int x = pst.executeUpdate();
				pst.close();
				con.close();
				if (x == 1) {
					System.out.println("Record Inserted");
					menuMethod.menu();
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}
		} else if (typeOfInsert.equalsIgnoreCase("Department")) {
			/**
			 * // Department Inserting Data ########
			 */
			Department department = new Department();

			System.out.println("Enter your Name here:");
			String name = sc.next();
			department.setName(name);

			System.out.println("Enter your Department Name here:");
			String departmentName = sc.next();
			department.setDepartmentName(departmentName);

			System.out.println("Enter your Department Id here:");
			int departmentId = sc.nextInt();
			department.setDepartmentId(departmentId);

			System.out.println("Enter your Addmission Date here (yyyy-mm-dd):");
			String addmissionDate = sc.next();
			department.setAddmissionDate(addmissionDate);

			System.out.println("Enter your Status here:");
			int status = sc.nextInt();
			department.setStatus(status);

			try {
				Connection con = DbConnection.getConnect();
				PreparedStatement pst = con.prepareStatement(
						"Insert into departments(name,departmentName,departmentId,addmissionDate, status)values(?,?,?,?,?,?)");
				//pst.setInt(1, department.getId());
				pst.setString(1, department.getName());
				pst.setString(2, department.getDepartmentName());
				pst.setInt(3, department.getDepartmentId());
				pst.setString(4, department.getAddmissionDate());
				pst.setInt(5, department.getStatus());

				int x = pst.executeUpdate();
				pst.close();
				con.close();
				if (x == 1) {
					System.out.println("Record Inserted");
					menuMethod.menu();
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}
		} else if (typeOfInsert.equalsIgnoreCase("Admin")) {
			/**
			 * // Admin Inserting Data ########
			 */
			Admin admin = new Admin();
			System.out.println("Enter your Name here:");
			String name = sc.next();
			admin.setName(name);

			System.out.println("Enter your Stream Name here:");
			String streamName = sc.next();
			admin.setStreamName(streamName);

			System.out.println("Enter your Addmission Id here:");
			int addmissionId = sc.nextInt();
			admin.setAddmissionId(addmissionId);

			System.out.println("Enter your Addmission Date here (yyyy-mm-dd):");
			String addmissionDate = sc.next();
			admin.setAddmissionDate(addmissionDate);

			System.out.println("Enter your Status here:");
			int status = sc.nextInt();
			admin.setStatus(status);
			
			System.out.println("Enter your Email here:");
			String email = sc.next();
			admin.setEmail(email);
			
			System.out.println("Enter your Password here:");
			String password = sc.next();
			admin.setPassword(password);

			try {
				Connection con = DbConnection.getConnect();
				PreparedStatement pst = con.prepareStatement(
						"Insert into admin(name,streamName,addmissionId,addmissionDate,status,email,password)values(?,?,?,?,?,?,?)");
				//pst.setInt(1, admin.getId());
				pst.setString(1, admin.getName());
				pst.setString(2, admin.getStreamName());
				pst.setInt(3,	 admin.getAddmissionId());
				pst.setString(4, admin.getAddmissionDate());
				pst.setInt(5, admin.getStatus());
				pst.setString(6, admin.getEmail());
				pst.setString(7, admin.getPassword());

				int x = pst.executeUpdate();
				pst.close();
				con.close();
				if (x == 1) {
					System.out.println("Record Inserted");
					menuMethod.menu();
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}

		} else if (typeOfInsert.equalsIgnoreCase("Liberary")) {
			/**
			 * // Library Inserting Data ########
			 */
			Liberary liberary = new Liberary();
			System.out.println("Enter your Name here:");
			String name = sc.next();
			liberary.setName(name);

			System.out.println("Enter your Stream Name here:");
			String streamName = sc.next();
			liberary.setStreamName(streamName);

			System.out.println("Enter your Liberary Id here:");
			int libId = sc.nextInt();
			liberary.setLibId(libId);

			System.out.println("Enter your College Name here:");
			String collegeName = sc.next();
			liberary.setCollegeName(collegeName);

			System.out.println("Enter your Status here:");
			int status = sc.nextInt();
			liberary.setStatus(status);

			try {
				Connection con = DbConnection.getConnect();
				PreparedStatement pst = con.prepareStatement(
						"Insert into liberary(name,streamName,libId,collegeName,status)values(?,?,?,?,?)");

				pst.setString(1, liberary.getName());
				pst.setString(2, liberary.getStreamName());
				pst.setInt(3, liberary.getLibId());
				pst.setString(4, liberary.getCollegeName());
				pst.setInt(5, liberary.getStatus());

				int x = pst.executeUpdate();
				pst.close();
				con.close();
				if (x == 1) {
					System.out.println("Record Inserted");
					menuMethod.menu();
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}

		} else if (typeOfInsert.equalsIgnoreCase("Sport")) {
			/**
			 * // Sports Inserting Data ########
			 */
			Sports sport = new Sports();

			System.out.println("Enter your Name here:");
			String name = sc.next();
			sport.setName(name);

			System.out.println("Enter your Stream Name here:");
			String streamName = sc.next();
			sport.setStreamName(streamName);

			System.out.println("Enter your Sport Id here:");
			int sportsId = sc.nextInt();
			sport.setSportsId(sportsId);

			System.out.println("Enter your Sport Name here:");
			String sportsName = sc.next();
			sport.setSportsName(sportsName);

			System.out.println("Enter your Status here:");
			int status = sc.nextInt();
			sport.setStatus(status);

			try {
				Connection con = DbConnection.getConnect();
				PreparedStatement pst = con.prepareStatement(
						"Insert into sports(name,streamName,sportsId,sportsName, status)values(?,?,?,?,?)");

				pst.setString(1, sport.getName());
				pst.setString(2, sport.getStreamName());
				pst.setInt(3, sport.getSportsId());
				pst.setString(4, sport.getSportsName());
				pst.setInt(5, sport.getStatus());

				int x = pst.executeUpdate();
				pst.close();
				con.close();
				if (x == 1) {
					System.out.println("Record Inserted");
					menuMethod.menu();
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}

		}
	}
}
