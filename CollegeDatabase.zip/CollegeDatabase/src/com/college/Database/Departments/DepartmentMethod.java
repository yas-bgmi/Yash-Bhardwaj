package com.college.Database.Departments;

import java.util.Scanner;

import com.college.Database.ActiveDataFromDatabase;
import com.college.Database.DeleteDataFromDatabase;
import com.college.Database.DisplayDataFromDatabase;
import com.college.Database.InactiveDataFromDatabase;
import com.college.Database.InsertDataIntoDatabase;
import com.college.Database.MenuMethod;
import com.college.Database.UpdateDataIntoDatabase;

/**
 * This is Department Method and it will use when we call request from CRUD
 * operations
 */

public class DepartmentMethod {
	Scanner sc = new Scanner(System.in);
	MenuMethod menuMethod = new MenuMethod();

	public String Department() {
		System.out.println("1. All Department \n" + "2. Insert Department \n" + "3. Update Department \n"
				+ "4. Delete Students\n" + "5. Active Status\n" + "6. Inactive Status\n" + "7. Main Menu");
		System.out.println("Enter Choice: ");
		InsertDataIntoDatabase ind = new InsertDataIntoDatabase();
		DeleteDataFromDatabase del = new DeleteDataFromDatabase();
		DisplayDataFromDatabase disp = new DisplayDataFromDatabase();
		UpdateDataIntoDatabase upd = new UpdateDataIntoDatabase();
		ActiveDataFromDatabase actdb = new ActiveDataFromDatabase();
		InactiveDataFromDatabase inactdb = new InactiveDataFromDatabase();

		int department = sc.nextInt();
		if (department == 1) {
			System.out.println("All Departments");
			disp.displayData("Department");
			Department();
		} else if (department == 2) {
			System.out.println("Insert New Department Name");
			ind.insertData("Department");
			Department();
		} else if (department == 3) {
			System.out.println("Update Existing User");
			upd.updateData("Department");
			Department();
		} else if (department == 4) {
			System.out.println("Delete Data");
			del.deleteData("Department");
			Department();
		} else if (department == 5) {
			System.out.println("Active Status");
			actdb.activeCollegeData("Department");
			Department();
		} else if (department == 6) {
			System.out.println("Inactive Status");
			inactdb.InactiveCollegeData("Department");
			Department();
		} else {
			menuMethod.menu();
		}

		// sc.close();
		return null;
	}
}
