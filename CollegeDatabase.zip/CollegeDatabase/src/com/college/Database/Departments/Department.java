package com.college.Database.Departments;

/**
 * This file is an Department main class which has stored getter & setter for
 * Department operations;;;;
 */

public class Department {

	private int id;
	private String name;
	private String departmentName;
	private int departmentId;
	private String addmissionDate;
	private int status;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public int getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}

	public String getAddmissionDate() {
		return addmissionDate;
	}

	public void setAddmissionDate(String date) {
		this.addmissionDate = date;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "Department [id=" + id + ", name=" + name + ", departmentName=" + departmentName + ", departmentId="
				+ departmentId + ", addmissionDate=" + addmissionDate + ", status=" + status + ", getId()=" + getId()
				+ ", getName()=" + getName() + ", getDepartmentName()=" + getDepartmentName() + ", getDepartmentId()="
				+ getDepartmentId() + ", getAddmissionDate()=" + getAddmissionDate() + ", getStatus()=" + getStatus()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
				+ "]";
	}

}
