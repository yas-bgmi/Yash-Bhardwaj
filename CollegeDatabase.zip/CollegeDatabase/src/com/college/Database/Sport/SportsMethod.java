package com.college.Database.Sport;

import java.util.Scanner;

import com.college.Database.ActiveDataFromDatabase;
import com.college.Database.DeleteDataFromDatabase;
import com.college.Database.DisplayDataFromDatabase;
import com.college.Database.InactiveDataFromDatabase;
import com.college.Database.InsertDataIntoDatabase;
import com.college.Database.MenuMethod;
import com.college.Database.UpdateDataIntoDatabase;

/**
 * This is Sports Method and it will use when we call request from CRUD
 * operations
 */

public class SportsMethod {
	Scanner sc = new Scanner(System.in);
	MenuMethod menuMethod = new MenuMethod();

	public String Sport() {

		System.out.println("1. All Sports\n" + "2. Insert Spots\n" + "3. Update Spots\n" + "4. Delete Students\n"
				+ "5. Active Status\n" + "6. Inactive Status\n" + "7. Main Menu");
		System.out.println("Enter Choice: ");
		InsertDataIntoDatabase ind = new InsertDataIntoDatabase();
		DeleteDataFromDatabase del = new DeleteDataFromDatabase();
		DisplayDataFromDatabase disp = new DisplayDataFromDatabase();
		UpdateDataIntoDatabase upd = new UpdateDataIntoDatabase();
		ActiveDataFromDatabase actdb = new ActiveDataFromDatabase();
		InactiveDataFromDatabase inactdb = new InactiveDataFromDatabase();

		int sport = sc.nextInt();
		if (sport == 1) {
			System.out.println("All Sports");
			disp.displayData("Sport");
			Sport();
		} else if (sport == 2) {
			System.out.println("Insert New Sport Name");
			ind.insertData("Sport");
			Sport();
		} else if (sport == 3) {
			System.out.println("Update Existing User");
			upd.updateData("Sport");
			Sport();
		} else if (sport == 4) {
			System.out.println("Delete Data");
			del.deleteData("Sport");
			Sport();
		} else if (sport == 5) {
			System.out.println("Active Status");
			actdb.activeCollegeData("Sport");
			Sport();
		} else if (sport == 6) {
			System.out.println("Inactive Status");
			inactdb.InactiveCollegeData("Sport");
			Sport();
		} else {
			menuMethod.menu();
		}

		// sc.close();
		return null;

	}

}
